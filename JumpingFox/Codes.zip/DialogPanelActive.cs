using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DialogPanelActive : MonoBehaviour
{
    [Header("�Ի����Կ������")]
    [Tooltip("�Ի���Panel")]
    public GameObject Panel;
    [Tooltip("������Ϸ�����������ţ�0��ʾ������ʾ��1��ʾ�����ؿ���ʾ��")]
    public int Type;
    [Tooltip("Դ�ı�")]
    public Text TextSource;
    [Tooltip("����ı�")]
    public Text OutPut;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            OutPut.text = TextSource.text;
            Panel.transform.GetChild(Type).gameObject.SetActive(true);
            Panel.SetActive(true);
            Panel.GetComponent<DialogAnimationController>().SetType(Type);
            Panel.GetComponent<DialogAnimationController>().SetIsActive(true);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            Panel.SetActive(false);
            Panel.transform.GetChild(Type).gameObject.SetActive(false);
            Panel.GetComponent<DialogAnimationController>().SetIsActive(false);
            OutPut.text = "";
        }
    }
}
