using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogAnimationController : MonoBehaviour
{
    private Animator animt;
    private int Type;
    private bool IsActive;

    private void Start()
    {
        animt = GetComponent<Animator>();
    }

    private void Update()
    {
        SwitchAnimation();
    }

    public void SetIsActive(bool IsActive)
    {
        this.IsActive = IsActive;
    }

    public void SetType(int Type) 
    {
        this.Type = Type;
    }

    private void SwitchAnimation() 
    {
        animt.SetInteger("Type",Type);
        animt.SetBool("IsActive",IsActive);
    }
}
