using UnityEngine;

public class BloodChange : MonoBehaviour
{
    public GameObject bloods;
    private static int index=4;

    public int GetIndex() 
    {
        return index;
    }

    public void addIndex() 
    {
        if (index < 4 && bloods.activeInHierarchy) 
        {
            index++;
            bloods.transform.GetChild(index).gameObject.SetActive(true);
        }
    }

    public void reduceIndex()
    {
        if (index >= 0 && bloods.activeInHierarchy) 
        {
            //���ɸ��������д���˳��
            bloods.transform.GetChild(index).gameObject.SetActive(false);
            index--;
        }
    }

    public void ReBloodsUI() 
    {
        if (index >= 0 && bloods.activeInHierarchy) 
        {
            for (int i = 0; i <= index; i++)
            {
                bloods.transform.GetChild(i).gameObject.SetActive(true);
            }
            for (int j = index+1; j <= 4; j++) 
            {
                bloods.transform.GetChild(j).gameObject.SetActive(false);
            }
        } 
    }

    public void setIndex(int num) 
    {
        index = num;
    }
}
