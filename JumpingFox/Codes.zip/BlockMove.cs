using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockMove : MonoBehaviour
{
    [Tooltip("Point����")]
    public Transform[] Points;
    //X��Y�ֱ��ʾ�˶��ľ�������Ŀ��͸�
    private float X,Y;
    //SizeM��SizeN�ֱ��ʾ����Ϸ�������ײ���Ŀ��͸�
    private float SizeM, SizeN;
    //ԭ��
    [Tooltip("ԭ��")]
    public Transform Point;
    private Rigidbody2D rb;
    //true��ʾ����ϣ�false��ʾ�һ���
    private bool Direction;
    [Tooltip("�����ƶ����ٶ�")]
    public float speed;
    [Tooltip("�����˶��ķ���(0��ʾ����,1��ʾ����)")]
    public int MoveDirections;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        SizeM = GetComponent<BoxCollider2D>().size.x;
        SizeN = GetComponent<BoxCollider2D>().size.y;
    }

    // Update is called once per frame
    void Update()
    {
        MoveDirection();
        Movement();
    }

    private void MoveDirection() 
    {
        //Debug.Log("SizeM:"+SizeM+"  SizeN:"+SizeN);
        if (MoveDirections == 0)
        {
            //Points[0]��ʾ�󶥵㣬Points[1]��ʾ�Ҷ���
            X = Points[1].transform.position.x - Points[0].transform.position.x;
            //Debug.Log("X:"+X);
            if (transform.localScale.x > 0)
            {
                //��ʾ��
                Direction = true;
            }
            if (transform.localScale.x < 0)
            {
                //��ʾ��
                Direction = false;
            }
        }
        if (MoveDirections == 1) 
        {
            //Points[0]��ʾ�϶��㣬Points[1]��ʾ�¶���
            Y = Points[0].transform.position.y - Points[1].transform.position.y;
            //Debug.Log("Y:" + Y);
            if (transform.localScale.y > 0)
            {
                //��ʾ��
                Direction = true;
            }
            if (transform.localScale.y < 0)
            {
                //��ʾ��
                Direction = false;
            }
        }
    }

    private void ChangeDirection() 
    {
        if (MoveDirections == 0)
        {
            if (transform.localScale.x > 0)
            {
                //�����Ϊ��
                transform.localScale = new Vector2(-1,1);
            }
            else
            {
                //�����Ϊ��
                transform.localScale = new Vector2(1, 1);
            }
        }
        if (MoveDirections == 1)
        {
            if (transform.localScale.y > 0)
            {
                //�����Ϊ��
                transform.localScale = new Vector2(1, -1);
            }
            else
            {
                //�����Ϊ��
                transform.localScale = new Vector2(1,1);
            }
        }
    }

    private void Movement()  
    {
        //�����ƶ�
        if (MoveDirections == 0) 
        {
            if (Direction) 
                rb.velocity = new Vector2(-speed, rb.velocity.y);
            else
                rb.velocity = new Vector2(speed, rb.velocity.y);
        }
        //�����ƶ�
        if (MoveDirections == 1)
        {
            if (Direction)
                rb.velocity = new Vector2(rb.velocity.x, speed);
            else
                rb.velocity = new Vector2(rb.velocity.x, -speed);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.transform.tag != "Player"&&collision.transform.tag != "Enemy") 
        {
            Debug.Log("������ײ��");
            ChangeDirection();
        }
    }
}
