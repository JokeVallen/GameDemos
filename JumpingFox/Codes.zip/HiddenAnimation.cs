using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HiddenAnimation : MonoBehaviour
{
    private Animator animt;
    private bool isStart;
    // Start is called before the first frame update
    void Start()
    {
        animt = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        SwitchAnimation();
    }

    public void SetIsStart(bool isStart) 
    {
        this.isStart = isStart;
    }

    private void SwitchAnimation() 
    {
        if (isStart) 
        {
            animt.SetBool("start", true);
        }
    }

    private void CloseAnimation() 
    {
        animt.SetBool("start", false);
        isStart = false;
    }
}
