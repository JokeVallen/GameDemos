using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;

public class PauseMenu : MonoBehaviour
{
    public Transform Bgm;
    public AudioMixer MainMixer;
    private GameObject obj;
    private FoodInfo[] Foods;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Cancel")) 
        {
            if (transform.GetChild(0).GetChild(6).gameObject.activeInHierarchy|| transform.GetChild(0).GetChild(7).gameObject.activeInHierarchy)
            {
                transform.GetChild(0).GetChild(6).gameObject.SetActive(false);
                transform.GetChild(0).GetChild(7).gameObject.SetActive(false);
                //��Ϸ����
                Time.timeScale = 1f;
            }
            else 
            {
                transform.GetChild(0).GetChild(6).gameObject.SetActive(true);
                //��Ϸ��ͣ
                Time.timeScale = 0f;
            }
        }
    }

    public void ChangeVolume(float volume) 
    {
        MainMixer.SetFloat("volume", volume);
    }

    public void BackMainMenu() 
    {
        transform.GetChild(0).GetChild(7).gameObject.SetActive(true);
        transform.GetChild(0).GetChild(6).gameObject.SetActive(false);
        transform.parent.GetChild(0).GetChild(4).GetComponent<BloodChange>().setIndex(4);
    }

    public void Confirm() 
    {
        ReAllData();
        SceneManager.LoadScene("Mainmenu");
        Time.timeScale = 1f;
    }

    public void Cancel() 
    {
        transform.GetChild(0).GetChild(7).gameObject.SetActive(false);
        transform.GetChild(0).GetChild(6).gameObject.SetActive(true);
    }

    public void QuitGame() 
    {
        Application.Quit();
    }

    //���������������ȫ�ֱ������͵�����
    private void ReAllData()
    {
        //��������ʰȡ��Ʒ������
        obj = GameObject.FindGameObjectWithTag("FoodController");
        if (obj != null)
        {
            Foods = obj.GetComponent<FoodsCount>().GetFoodCount();
            for (int i = 0; i < Foods.Length; i++)
            {
                obj.GetComponent<FoodsCount>().SetFoodCount(0, Foods[i].FoodName);
            }
        }
    }
}
