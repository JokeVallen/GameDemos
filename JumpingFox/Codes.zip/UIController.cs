using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIController : MonoBehaviour
{
    [Tooltip("�˴���˳������ѭ�洢�Ŀ�ʰȡ��Ʒ����Ϣ���е�˳��")]
    public Text[] FoodCount;
    [Tooltip("��ǰ�ؿ���ʾUI")]
    public Transform LevelPanel;
    [Tooltip("��Ϸ������ʾUI")]
    public Transform GameOverPanel;
    [Tooltip("Ѫ��������Ϸ����")]
    public GameObject bloodChange;

    private FoodInfo[] NowFood;
    private GameObject Foods;
    private bool gameOver = true;

    private void Start()
    {
        Foods = GameObject.FindGameObjectWithTag("FoodController");
        if (Foods == null)
        {
            var message = "Your GameObject named 'Foods' is null.";
            Debug.Log(message);
        }
        else 
        {
            NowFood = Foods.GetComponent<FoodsCount>().GetFoodCount();
        }
        LevelPanel.gameObject.SetActive(true);
    }
    // Update is called once per frame
    void Update()
    {
        BloodInspector();
        FoodInspector();
    }

    public void FoodInspector() 
    {
        if (NowFood != null) 
        {
            for (int i = 0; i < NowFood.Length; i++)
            {
                FoodCount[i].text = NowFood[i].GetFoodNumber().ToString();
            }
        }
    }

    public void BloodInspector()
    {
        if (bloodChange != null && bloodChange.GetComponent<BloodChange>().GetIndex() == -1 && gameOver)
        {
            Time.timeScale = 0f;
            GameOverPanel.gameObject.SetActive(true);
            gameOver = false;
            bloodChange.GetComponent<BloodChange>().setIndex(4);
        }
    }
}
