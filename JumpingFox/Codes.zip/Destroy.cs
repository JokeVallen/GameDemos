using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;
using UnityEngine.UI;

public class Destroy : MonoBehaviour
{
    public Sprite spr;
    public BoxCollider2D coll;
    private GameObject obj;
    private float BoxX,BoxY;
    private void Start()
    {
        //��ʼ��&&��ֵ
        obj = GameObject.FindGameObjectWithTag("DontDestroy");
        BoxX = coll.gameObject.transform.position.x;
        BoxY = coll.gameObject.transform.position.y;
        //�ı���Ϸ������ֵ
        obj.transform.GetChild(5).position = new Vector3(BoxX,BoxY,60);
        obj.transform.GetChild(5).transform.GetComponent<SpriteRenderer>().sprite = spr;
        DestroyImmediate(obj.transform.GetChild(5).transform.GetComponent<BoxCollider2D>());
        obj.transform.GetChild(5).gameObject.AddComponent(typeof(BoxCollider2D));
        obj.transform.GetChild(5).transform.GetComponent<BoxCollider2D>().offset = coll.offset;
        obj.transform.GetChild(5).transform.GetComponent<BoxCollider2D>().size = coll.size;
        obj.transform.GetChild(5).transform.GetComponent<BoxCollider2D>().isTrigger = true;
        obj.transform.GetChild(2).gameObject.SetActive(false);
        obj.transform.GetChild(0).GetChild(1).gameObject.SetActive(true);
        obj.transform.GetChild(1).GetChild(0).GetChild(1).GetComponent<Text>().color = new Color32(255, 255, 255, 255);
        obj.transform.GetChild(1).GetChild(0).GetChild(3).GetComponent<Text>().color = new Color32(255, 255, 255, 255);
    }
}
