using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShowUIs : MonoBehaviour
{
    private GameObject obj;
    void Start()
    {
        obj = GameObject.FindGameObjectWithTag("DontDestroy");
        if (obj != null)
        {
            obj.transform.GetChild(1).GetChild(0).GetChild(8).transform.gameObject.SetActive(true);
            obj.transform.GetChild(0).GetChild(4).GetComponent<BloodChange>().ReBloodsUI();
        }
    }
}
