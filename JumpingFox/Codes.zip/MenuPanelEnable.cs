using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuPanelEnable : MonoBehaviour
{
    public Transform menu;
    public void EnableButton()
    {
        menu.GetComponent<Menu>().MenuEnable();
    }
}
