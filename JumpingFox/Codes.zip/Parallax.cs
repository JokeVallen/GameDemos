using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Parallax : MonoBehaviour
{
    //ע�⣺Area������ΪBackground�ĵ�һ��������
    [Tooltip("��ǰ��������")]
    public string ActiveSceneName;
    public Transform area;
    public Transform cam;
    public float MoveRate;
    private Transform pe;
    private float startPointX,startPointY;
    private float areaX, areaY;
    // Start is called before the first frame update
    void Start()
    {
        pe = GameObject.FindGameObjectWithTag("Parallax").transform;
        startPointX = transform.position.x;
        startPointY = transform.position.y;
        if (area != null)
        {
            areaX = area.GetComponent<PolygonCollider2D>().bounds.extents.x;
            areaY = area.GetComponent<PolygonCollider2D>().bounds.extents.y;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (SceneManager.GetActiveScene().buildIndex <= 3) 
        {
            if (area != null) 
            {
                if (areaX >= areaY) 
                {
                    transform.position = new Vector2(startPointX + cam.position.x * MoveRate, transform.position.y);
                }
                else 
                {
                    transform.position = new Vector2(transform.position.x, startPointY + cam.position.y * MoveRate);
                }
            }
            
        }
        else if (SceneManager.GetActiveScene().name == ActiveSceneName) 
        {
            if (area != null) 
            {
                if (areaX >= areaY) 
                {
                    transform.position = new Vector2(startPointX + cam.position.x * MoveRate, transform.position.y);
                }
                else 
                {
                    transform.position = new Vector2(transform.position.x, startPointY + cam.position.y * MoveRate);
                }
            }
            
        }
        else
        {
            if (pe != null&&pe.GetComponent<ParallaxEnable>().Get_PeFinish())
            {
                cam = GameObject.FindGameObjectWithTag("DontDestroy").transform.GetChild(3).GetChild(0);
                if (area != null)
                {
                    if (areaX >= areaY)
                    {
                        transform.position = new Vector2(startPointX + cam.position.x * MoveRate, transform.position.y);
                    }
                    else
                    {
                        transform.position = new Vector2(transform.position.x, startPointY + cam.position.y * MoveRate);
                    }
                }
            } 
        }
    }
}
