using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ParallaxEnable : MonoBehaviour
{
    private GameObject obj;
    private bool DestroyFinish = false;
    private bool PeFinish = false;
    private bool start = false;

    private void Update()
    {
        if (SceneManager.GetActiveScene().buildIndex >= 2 && DestroyFinish && !start)
        {
            Initialize();
        }
    }

    private void Initialize()
    {
        PeFinish = true;
        start = true;
    }

    public bool Get_PeFinish() 
    {
        return PeFinish;
    }

    public void Set_DestroyFinish(bool DestroyFinish) 
    {
        this.DestroyFinish = DestroyFinish;
    }
}
