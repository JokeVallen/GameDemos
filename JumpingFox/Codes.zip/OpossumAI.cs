using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpossumAI : Enemy
{
    public float speed;
    public Transform leftpoint, rightpoint;
    private float leftx, rightx;
    private Rigidbody2D rb;
    //falseΪ��trueΪ��
    private bool Direction = false;
    // Start is called before the first frame update
    protected override void Start()
    {
        base.Start();
        rb = GetComponent<Rigidbody2D>();
        leftx = leftpoint.position.x;
        rightx = rightpoint.position.x;
        Destroy(leftpoint.gameObject);
        Destroy(rightpoint.gameObject);
    }

    // Update is called once per frame
    void Update()
    {
        Movement();
    }

    private void MoveDirection()
    {
        if (transform.position.x <= leftx)
            Direction = true;
        if (transform.position.x >= rightx)
            Direction = false;
    }

    private void Movement()
    {
        MoveDirection();
        if (!Direction)
        {
            transform.localScale = new Vector3(1, 1, 1);
            rb.velocity = new Vector2(-speed, rb.velocity.y);
        }
        else
        {
            transform.localScale = new Vector3(-1, 1, 1);
            rb.velocity = new Vector2(speed, rb.velocity.y);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && collision.GetContact(0).normal.y >= -1 && collision.GetContact(0).normal.y < 0 && !base.GetDeath())
        {
            base.AudioPlay();
            animt.SetTrigger("death");
            base.SetDeath(true);
        }
    }

    private void Death()
    {
        Destroy(gameObject);
    }
}
