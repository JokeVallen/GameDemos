using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockMoveOfPoint : MonoBehaviour
{
    [Tooltip("Point����")]
    public Transform[] Points;
    private Rigidbody2D rb;
    //true��ʾ����ϣ�false��ʾ�һ���
    private bool Direction = true;
    [Tooltip("�����ƶ����ٶ�")]
    public float speed;
    [Tooltip("�����˶��ķ���(0��ʾ����,1��ʾ����)")]
    public int MoveDirections;


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        Movement();
        ChangeDirection();
    }

    private void ChangeDirection()
    {
        if (MoveDirections == 0)
        {
            if (transform.position.x <= Points[0].position.x)
            {
                //�����Ϊ��
                Direction = false;
            }
            if(transform.position.x >= Points[1].position.x)
            {
                //�����Ϊ��
                Direction = true;
            }
        }
        if (MoveDirections == 1)
        {
            if (transform.position.y >= Points[0].position.y)
            {
                //�����Ϊ��
                Direction = false;
            }
            if(transform.position.y <= Points[1].position.y)
            {
                //�����Ϊ��
                Direction = true;
            }
        }
    }

    private void Movement()
    {
        //�����ƶ�
        if (MoveDirections == 0)
        {
            if (Direction)
                rb.velocity = new Vector2(-speed, rb.velocity.y);
            else
                rb.velocity = new Vector2(speed, rb.velocity.y);
        }
        //�����ƶ�
        if (MoveDirections == 1)
        {
            if (Direction)
                rb.velocity = new Vector2(rb.velocity.x, speed);
            else
                rb.velocity = new Vector2(rb.velocity.x, -speed);
        }
    }

}
