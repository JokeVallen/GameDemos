using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    protected Animator animt;
    protected AudioSource DeathAudio;
    private bool hurt;
    private bool death;
    // Start is called before the first frame update
    protected virtual void Start()
    {
        animt = GetComponent<Animator>();
        DeathAudio = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    public void AudioPlay() 
    {
        DeathAudio.Play();
    }

    public bool GetHurt() 
    {
        return hurt;
    }

    public void SetHurt(bool hurt) 
    {
        this.hurt = hurt;
    }

    public bool GetDeath() 
    {
        return death;
    }

    public void SetDeath(bool death) 
    {
        this.death = death;
    }
}
