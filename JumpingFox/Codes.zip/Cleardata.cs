using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cleardata : MonoBehaviour
{
    public GameObject Foods;

    private void Start()
    {
        if (Foods == null) 
        {
            var message = "Your GameObject named 'Foods' is null.";
            Debug.Log(message);
        }
    }

    private void Update()
    {
        Clear();
    }

    public void Clear()
    {
        Foods.GetComponent<FoodsCount>().SetFoodCount(0, "Cherry");
        Foods.GetComponent<FoodsCount>().SetFoodCount(0, "Gem");
    }
}
