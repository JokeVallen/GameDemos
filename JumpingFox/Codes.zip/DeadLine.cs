using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DeadLine : MonoBehaviour
{
    private FoodInfo[] LastFoods;
    private GameObject bloodChange;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.transform.tag == "Player")
        {
            Invoke("Restart",1f);
        }
    }

    private void Restart()
    {
        if (SceneManager.GetActiveScene().buildIndex == 3)
        {
            bloodChange = GameObject.FindGameObjectWithTag("BloodChange");
            if (bloodChange != null)
            {
                bloodChange.GetComponent<BloodChange>().reduceIndex();
            }
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            Redata();
        }
        else 
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    private void Redata()
    {
        LastFoods = GameObject.FindGameObjectWithTag("FoodController").GetComponent<FoodsCount>().GetFoodCount();
        if (LastFoods != null)
        {
            for (int i = 0; i < LastFoods.Length; i++)
            {
                GameObject.FindGameObjectWithTag("FoodController").GetComponent<FoodsCount>().SetFoodCount(LastFoods[i].GetLastNumber(), LastFoods[i].FoodName);
            }
        }
    }
}
