using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PortalButton : MonoBehaviour
{
    private bool IsActive;
    public AudioSource Click;
    public PortalManager manager1;

    private void Awake()
    {
        IsActive = false;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            IsActive = true ;
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        IsActive = false;
    }

    // Update is called once per frame
    private void Update()
    {
        if (Input.GetButtonDown("Interaction")&&IsActive)
        {
            Click.Play();
            manager1.Loading1();
        }
    }
}
