using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LevelPanelManager : MonoBehaviour
{
    private string SceneName,ForeName;
    private Animator animt;
    private void Start()
    {
        animt = GetComponent<Animator>();
    }

    private void Update()
    {
        SceneName = SceneManager.GetActiveScene().name;
        LevelStart();
    }

    private void LevelStart() 
    {
        if (!SceneName.Equals(ForeName))
        {
            transform.GetChild(0).GetComponent<Text>().text = SceneName;
            animt.SetBool("start", true);
        }
    }

    private void LevelEnd() 
    {
        animt.SetBool("start",false);
        gameObject.SetActive(false);
        ForeName = SceneName;
    }
}
