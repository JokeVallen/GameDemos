using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    public AudioSource PlayAd;
    public Animator animt;
    private bool isOK = false;

    private void Update()
    {
        if (!isOK) 
        {
            AnimationControl();
            isOK = true;
        }
    }

    private void AnimationControl() 
    {
        if (!transform.GetChild(2).GetChild(0).gameObject.activeInHierarchy)
        {
            transform.GetChild(2).GetChild(0).gameObject.SetActive(true);
            animt.Play("MenuUI",0,0);
        }
        else
        {
            animt.Play("MenuUI", 0, 0);
        }
    }

    public void PlayPlotGame() 
    {
        PlayAd.Play();
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex+1);
    }

    public void PlayParkourGame()
    {
        PlayAd.Play();
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 2);
    }

    public void QuitGame() 
    {
        PlayAd.Play();
        Application.Quit();
    }

    public void MenuEnable() 
    {
        transform.GetChild(2).GetChild(1).gameObject.SetActive(true);
    }
}
