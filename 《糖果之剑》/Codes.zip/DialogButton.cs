using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogButton : MonoBehaviour
{
    public GameObject Button;
    public GameObject talkUI;
    public AudioSource Click;

    private void Awake()
    {
        Button.SetActive(false);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        Button.SetActive(true);
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        Button.SetActive(false);
        talkUI.SetActive(false);
    }

    // Update is called once per frame
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            Click.Play();
            talkUI.SetActive(true);
        }
    }
}
