using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DialogSystem : MonoBehaviour
{
    [Header("UI���")]
    public Text textLable;
    public Image faceImage;

    [Header("�ı����")]
    public TextAsset textFile;
    public int index;
    public float textSpeed;

    public string[] test;
    bool textFinished;
    bool textTyping;//�Ƿ��������

    List<string> textList = new List<string>();
    // Start is called before the first frame update
    void Awake()
    {
        GetTextFromFile(textFile);
    }
    private void OnEnable()
    {
        //textLable.text = textList[index];
        //index++;
        textFinished = true;
        StartCoroutine(SetTextUI());
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R) && index == textList.Count) {
            gameObject.SetActive(false);
            index = 0;
            return;
        }
        if (Input.GetKeyDown(KeyCode.R)) {
            //��ʱ��δ�������Ҳ��δ������
            if (textFinished && !textTyping)
            {
                StartCoroutine(SetTextUI());
            }
            //��ʱ���ڽ���������ǻ�δ������
            else if (!textFinished && !textTyping) {
                textTyping = true;
            }
            
        }
    }

    //
    public void GetTextFromFile(TextAsset file)
    {
        textList.Clear();
        index = 0;

        var lineData = file.text.Split('\n');

        foreach (var line in lineData) {
            textList.Add(line);
        }
    }

    //
    IEnumerator SetTextUI() {
        textFinished = false;
        textLable.text = "";

        switch (textList[index][0])
        {
            case 'A':
                index++;
                break;
            case 'B':
                index++;
                break;
            case 'C':
                index++;
                break;
            case 'D':
                index++;
                break;
            default:
                break;
        }
        int letter = 0;

        while (!textTyping && letter < textList[index].Length) {
            textLable.text += textList[index][letter];
            letter++;
            yield return new WaitForSeconds(textSpeed);
        }
        
        textLable.text = textList[index];
        textTyping = false;
        textFinished = true;
        index++;
    }

}
