using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using Cinemachine;
public class PortalManager : MonoBehaviour
{
    [Header("Ŀ�곡��������")]
    //�������Rooms
    public string TargetScene;
    [Header("���س�����Ҫ��������Ϸ����")]
    public GameObject[] Objs;
    //private GameObject[] obj;
    [Header("���������д���������")]
    //�����RoomGenerator��Ԥ����
    public RoomGenerator loadRoom;
    //[Header("����������ɺ��������")]
    //public GameObject basicRoom;
    // Start is called before the first frame update
    //private Transform trans;
    //private TransformHelper tran;
    Transform VCCAmera;
    public void Loading1() {
        StartCoroutine(LoadScene1());
        //basicRoom.GetComponent<BoxCollider2D>().enabled = false;
        SceneManager.LoadScene(TargetScene);

        //Scene room = SceneManager.GetSceneByBuildIndex(2);
        //obj = room.GetRootGameObjects();
        //if (obj.Length == 0) {
        //    Debug.Log(obj.Length);
        //}
        //trans = GetComponent<RoomGenerator>().ReFirstTransForm();
        //GameObject.FindGameObjectWithTag("Player").transform.position = trans.position;
        //GameObject.FindGameObjectWithTag("Player").GetComponentInParent<Transform>().position = new Vector3(0, 0, -10);


        //��Ϸ��������
        GameObject.FindGameObjectWithTag("Player").transform.position = new Vector3(0,0,0);
        GameObject.FindGameObjectWithTag("Player").transform.localScale = new Vector3(3, 3, 1);
        VCCAmera = TransformHelper.GetChild(Objs[0].transform, "CM vcam1");
        VCCAmera.GetComponent<CinemachineVirtualCamera>().m_Lens.OrthographicSize = 5f;
        Objs[6].transform.position = new Vector3(2, 2, 0);
    }


    IEnumerator LoadScene1() {
        if (Objs.Length != 0) {
            for (int i = 0; i < Objs.Length; i++) {
                DontDestroyOnLoad(Objs[i]);
            }
        }

        Scene Game = SceneManager.GetActiveScene();
        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(TargetScene,LoadSceneMode.Additive);

        while (!asyncLoad.isDone)
        {
            yield return null;
        }

        if (Objs.Length != 0) {
            for (int i = 0; i < Objs.Length; i++)
            {
                SceneManager.MoveGameObjectToScene(Objs[i], SceneManager.GetSceneByName(TargetScene));
            }
        }

        SceneManager.UnloadSceneAsync(Game);
    }
}
