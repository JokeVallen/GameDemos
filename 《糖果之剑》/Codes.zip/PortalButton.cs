using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PortalButton : MonoBehaviour
{
    public GameObject Button;
    public AudioSource Click;
    public PortalManager manager1;
    //public GameObject basicRoom;


    private void Awake()
    {
        Button.SetActive(false);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player")) {
            Button.SetActive(true);
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        Button.SetActive(false);
    }

    // Update is called once per frame
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.R)&&Button.activeInHierarchy)
        {
            Click.Play();
            manager1.Loading1();
        }
    }
}
