using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EasyGame;

public class ChangeBGM : ViewController
{
    public string MusicSetName;
    public string MusicClipName;
    [Range(0f, 1f)]
    public float MusicVolume;
    private AudioManagerSys audioManagerSys;
    void Start()
    {
        audioManagerSys = GameManager.Get<AudioManagerSys>();
        Change();
    }

    private void Change()
    {
        audioManagerSys.PlayMusic(MusicSetName, MusicClipName);
        audioManagerSys.ChangeVolume(MusicSetName, MusicVolume);
    }
}

