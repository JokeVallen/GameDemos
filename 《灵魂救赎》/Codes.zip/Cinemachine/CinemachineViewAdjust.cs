using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class CinemachineViewAdjust
{
    private GameObject cVCgameObject;
    private CinemachineVirtualCamera cVC;

    /// <summary>
    /// <para>作用：初始化相机抖动和渲染组件</para>
    /// </summary>
    private void InitComponents()
    {
        if (cVCgameObject == null)
        {
            cVCgameObject = GameObject.FindGameObjectWithTag("VCinemachine");
            cVC = cVCgameObject.GetComponent<CinemachineVirtualCamera>();
        }
    }

    /// <summary>
    /// <para>作用：设置虚拟相机（游戏对象）</para>
    /// <para>gameObject：虚拟相机游戏对象</para>
    /// </summary>
    public void SetVCgameObject(GameObject gameObject)
    {
        cVCgameObject = gameObject;
    }

    /// <summary>
    /// <para>作用：设置视野调整（属性）</para>
    /// <para>dict：属性参数字典</para>
    /// </summary>
    public void InitViewAdjust(Dictionary<string, float> dict)
    {
        InitComponents();
        foreach (var key in dict.Keys)
        {
            switch (key)
            {
                case cVaType.OrthographicSize:
                    cVC.m_Lens.OrthographicSize = dict[key];
                    break;
                case cVaType.NearClipPlane:
                    cVC.m_Lens.NearClipPlane = dict[key];
                    break;
                case cVaType.FarClipPlane:
                    cVC.m_Lens.FarClipPlane = dict[key];
                    break;
                case cVaType.Duth:
                    if (dict[key] >= -180 && dict[key] <= 180)
                    {
                        cVC.m_Lens.Dutch = dict[key];
                    }
                    break;
                default:
                    break;
            }
        }
    }

    /// <summary>
    /// <para>作用：获取视野调整属性字典</para>
    /// </summary>
    public Dictionary<string, float> GetVaDict()
    {
        InitComponents();
        Dictionary<string, float> dict = new Dictionary<string, float>();
        dict.Add(cVaType.OrthographicSize, cVC.m_Lens.OrthographicSize);
        dict.Add(cVaType.NearClipPlane, cVC.m_Lens.NearClipPlane);
        dict.Add(cVaType.FarClipPlane, cVC.m_Lens.FarClipPlane);
        dict.Add(cVaType.Duth, cVC.m_Lens.Dutch);
        return dict;
    }
}

public class cVaType
{
    public const string OrthographicSize = "OrthographicSize";
    public const string NearClipPlane = "NearClipPlane";
    public const string FarClipPlane = "FarClipPlane";
    public const string Duth = "Duth";
}
