using UnityEngine;
using Cinemachine;

public class CinemachineMove : MonoBehaviour
{
    [Header("必要组件")]
    [Tooltip("虚拟相机游戏对象")]
    //虚拟相机游戏对象
    public GameObject cVCinemachine;

    [Header("必要属性")]
    [Tooltip("角色和相机的x轴距离差值")]
    //角色和相机的x轴距离差值
    public float mCameraDistance;
    [Tooltip("相机移动的速度")]
    //相机移动的速度
    public float mCameraSpeed;
    [Tooltip("1表示向右，-1表示向左")]
    //1表示向右，-1表示向左
    public int mCameraDirection;

    //主角游戏对象
    private GameObject cPlayer;
    private Rigidbody2D cRigid_body;
    private bool mGet_rigidBody2d;
    private bool mEnd_status;

    private void Start()
    {
        cPlayer = GameObject.FindGameObjectWithTag("Player");
        if (cVCinemachine != null)
        {
            mGet_rigidBody2d = cVCinemachine.TryGetComponent<Rigidbody2D>(out cRigid_body);
        }
    }

    private void Update()
    {
        ChangeFollowObject();
        if (Mathf.Abs(cVCinemachine.transform.position.x - cPlayer.transform.position.x) <= mCameraDistance && !mEnd_status)
        {
            mEnd_status = true;
            ReturnFirstStatus();
        }
    }

    void ChangeFollowObject()
    {
        if (mGet_rigidBody2d)
        {
            if (Input.GetKey(KeyCode.E) && !mEnd_status)
            {
                MoveCamera();
            }
        }

    }

    void MoveCamera()
    {
        cVCinemachine.GetComponent<CinemachineVirtualCamera>().Follow = null;
        cRigid_body.velocity = new Vector2(mCameraDirection * mCameraSpeed, cRigid_body.velocity.y);
    }

    void ReturnFirstStatus()
    {
        cVCinemachine.GetComponent<CinemachineVirtualCamera>().Follow = cPlayer.transform;
        cVCinemachine.GetComponent<CinemachineVirtualCamera>().GetCinemachineComponent<CinemachineFramingTransposer>().m_XDamping = 0f;
    }
}
