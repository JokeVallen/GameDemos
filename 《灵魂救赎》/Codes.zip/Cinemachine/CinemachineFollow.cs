using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

/// <summary>
/// <para>功能：相机跟随</para>
/// </summary>
public class CinemachineFollow
{
    private GameObject cVCgameObject;
    private CinemachineVirtualCamera cVC;
    private CinemachineFramingTransposer cFT;

    /// <summary>
    /// <para>作用：初始化相机跟随组件</para>
    /// </summary>
    private void InitComponents()
    {
        if (cVCgameObject == null)
        {
            cVCgameObject = GameObject.FindGameObjectWithTag("VCinemachine");
            cVC = cVCgameObject.GetComponent<CinemachineVirtualCamera>();
            cFT = cVC.GetCinemachineComponent<CinemachineFramingTransposer>();
        }
    }

    /// <summary>
    /// <para>作用：设置虚拟相机（游戏对象）</para>
    /// <para>gameObject：虚拟相机游戏对象</para>
    /// </summary>
    public void SetVCgameObject(GameObject gameObject)
    {
        cVCgameObject = gameObject;
    }

    /// <summary>
    /// <para>作用：获取相机跟随（参数字典）</para>
    /// </summary>
    public Dictionary<string, float> GetVcDict()
    {
        InitComponents();
        Dictionary<string, float> dict = new Dictionary<string, float>();
        dict.Add(pType.LookaheadTime, cFT.m_LookaheadTime);
        dict.Add(pType.LookaheadSmoothing, cFT.m_LookaheadSmoothing);
        dict.Add(pType.XDamping, cFT.m_XDamping);
        dict.Add(pType.YDamping, cFT.m_YDamping);
        dict.Add(pType.ZDamping, cFT.m_ZDamping);
        dict.Add(pType.ScreenX, cFT.m_ScreenX);
        dict.Add(pType.ScreenY, cFT.m_ScreenY);
        dict.Add(pType.CameraDistance, cFT.m_CameraDistance);
        dict.Add(pType.DeadZoneWidth, cFT.m_DeadZoneWidth);
        dict.Add(pType.DeadZoneHeight, cFT.m_DeadZoneHeight);
        dict.Add(pType.DeadZoneDepth, cFT.m_DeadZoneDepth);
        dict.Add(pType.SoftZoneWidth, cFT.m_SoftZoneWidth);
        dict.Add(pType.SoftZoneHeight, cFT.m_SoftZoneHeight);
        dict.Add(pType.BiasX, cFT.m_BiasX);
        dict.Add(pType.BiasY, cFT.m_BiasY);
        return dict;
    }

    /// <summary>
    /// <para>作用：更改相机跟随对象</para>
    /// <para>transform：跟随对象的Transform组件</para>
    /// </summary>
    public void FollowChange(Transform transform)
    {
        InitComponents();
        cVC.Follow = transform;
    }

    /// <summary>
    /// <para>作用：设置虚拟相机跟随参数（Vector3型）</para>
    /// <para>trackedObjectOffset：Vector3参数</para>
    /// </summary>
    public void FollowParameter(Vector3 trackedObjectOffset)
    {
        InitComponents();
        cFT.m_TrackedObjectOffset = trackedObjectOffset;
    }

    /// <summary>
    /// <para>作用：设置虚拟相机跟随参数（bool型）</para>
    /// <para>type：参数名称(LookaheadIgnoreY/TargetMovementOnly/UnlimitedSoftZone/CenterOnActive)</para>
    /// <para>isActive：是否开启</para>
    /// </summary>
    public void FollowParameter(string type, bool isActive)
    {
        InitComponents();
        switch (type)
        {
            case pType.LookaheadIgnoreY:
                cFT.m_LookaheadIgnoreY = isActive;
                break;
            case pType.TargetMovementOnly:
                cFT.m_TargetMovementOnly = isActive;
                break;
            case pType.UnlimitedSoftZone:
                cFT.m_UnlimitedSoftZone = isActive;
                break;
            case pType.CenterOnActive:
                cFT.m_CenterOnActivate = isActive;
                break;
            default:
                Debug.Log("HGH:你要设置的参数不存在！");
                break;
        }
    }

    /// <summary>
    /// <para>作用：设置虚拟相机跟随参数（float型）</para>
    /// <para>dict：字典参数</para>
    /// </summary>
    public void FollowParameter(Dictionary<string, float> dict)
    {
        InitComponents();
        foreach (var key in dict.Keys)
        {
            switch (key)
            {
                case pType.LookaheadTime:
                    cFT.m_LookaheadTime = dict[key];
                    break;
                case pType.LookaheadSmoothing:
                    cFT.m_LookaheadSmoothing = dict[key];
                    break;
                case pType.XDamping:
                    cFT.m_XDamping = dict[key];
                    break;
                case pType.YDamping:
                    cFT.m_YDamping = dict[key];
                    break;
                case pType.ZDamping:
                    cFT.m_ZDamping = dict[key];
                    break;
                case pType.ScreenX:
                    cFT.m_ScreenX = dict[key];
                    break;
                case pType.ScreenY:
                    cFT.m_ScreenY = dict[key];
                    break;
                case pType.CameraDistance:
                    cFT.m_CameraDistance = dict[key];
                    break;
                case pType.DeadZoneWidth:
                    cFT.m_DeadZoneWidth = dict[key];
                    break;
                case pType.DeadZoneHeight:
                    cFT.m_DeadZoneHeight = dict[key];
                    break;
                case pType.DeadZoneDepth:
                    cFT.m_DeadZoneDepth = dict[key];
                    break;
                case pType.SoftZoneWidth:
                    cFT.m_SoftZoneWidth = dict[key];
                    break;
                case pType.SoftZoneHeight:
                    cFT.m_SoftZoneHeight = dict[key];
                    break;
                case pType.BiasX:
                    cFT.m_BiasX = dict[key];
                    break;
                case pType.BiasY:
                    cFT.m_BiasY = dict[key];
                    break;
                default:
                    Debug.Log("HGH:你要设置的参数不存在！");
                    break;
            }
        }
    }

    /// <summary>
    /// <para>作用：虚拟相机跟随（参数名称）</para>
    /// </summary>
    public struct pType
    {
        public const string TrackedObjectOffset = "TrackedObjectOffset";
        public const string LookaheadTime = "LookaheadTime";
        public const string LookaheadSmoothing = "LookaheadSmoothing";
        public const string LookaheadIgnoreY = "LookaheadIgnoreY";
        public const string XDamping = "XDamping";
        public const string YDamping = "YDamping";
        public const string ZDamping = "ZDamping";
        public const string TargetMovementOnly = "TargetMovementOnly";
        public const string ScreenX = "ScreenX";
        public const string ScreenY = "ScreenY";
        public const string CameraDistance = "CameraDistance";
        public const string DeadZoneWidth = "DeadZoneWidth";
        public const string DeadZoneHeight = "DeadZoneHeight";
        public const string DeadZoneDepth = "DeadZoneDepth";
        public const string UnlimitedSoftZone = "UnlimitedSoftZone";
        public const string SoftZoneWidth = "SoftZoneWidth";
        public const string SoftZoneHeight = "SoftZoneHeight";
        public const string BiasX = "BiasX";
        public const string BiasY = "BiasY";
        public const string CenterOnActive = "CenterOnActive";
    }
}
