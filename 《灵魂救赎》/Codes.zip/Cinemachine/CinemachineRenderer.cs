using UnityEngine;
using UnityEditor;
using Cinemachine;
#if UNITY_EDITOR
using Cinemachine.Editor;
#endif

#if UNITY_EDITOR
/// <summary>
/// <para>功能：相机抖动、相机渲染</para>
/// </summary>
public class CinemachineRenderer
{
    private GameObject cVCgameObject;
    private CinemachineImpulseListener cIL;
    private string mPath = "Assets/HGH/Expackage/CinemachineAssets/CinemachineImpulseChannels.asset";
    private CinemachineImpulseChannels cIC;


    /// <summary>
    /// <para>作用：初始化相机抖动和渲染组件</para>
    /// </summary>
    private void InitComponents()
    {
        if (cVCgameObject == null)
        {
            cVCgameObject = GameObject.FindGameObjectWithTag("VCinemachine");
            cIL = cVCgameObject.GetComponent<CinemachineImpulseListener>();
            cIC = AssetDatabase.LoadAssetAtPath<CinemachineImpulseChannels>(mPath);
        }
    }

    /// <summary>
    /// <para>作用：设置虚拟相机（游戏对象）</para>
    /// <para>gameObject：虚拟相机游戏对象</para>
    /// </summary>
    public void SetVCgameObject(GameObject gameObject)
    {
        cVCgameObject = gameObject;
    }

    /// <summary>
    /// <para>作用：ImpulseListener的ChannelMask参数设置</para>
    /// <para>channelMask：ChannelMask参数名称</para>
    /// </summary>
    public void ImpulseListener(string channelMask)
    {
        InitComponents();
        cIL.m_ChannelMask = getChannelMask(channelMask);
    }

    /// <summary>
    /// <para>作用：获取channelMask的索引号</para>
    /// <para>channelMask：ChannelMask参数名称</para>
    /// </summary>
    private int getChannelMask(string channelMask)
    {
        InitComponents();
        string[] impulseMask = cIC.ImpulseChannels;
        int index = 0;
        if (channelMask == "Nothing")
        {
            index = 0;
        }
        else if (channelMask == "Everything")
        {
            index = impulseMask.Length + 1;
        }
        else
        {
            index = 1;
            foreach (var value in impulseMask)
            {
                if (channelMask == value)
                {
                    break;
                }
                index++;
            }
        }
        return index;
    }

    /// <summary>
    /// <para>作用：ImpulseListener的Gain参数设置</para>
    /// <para>gain：Gain参数</para>
    /// </summary>
    public void ImpulseListener(float gain)
    {
        InitComponents();
        cIL.m_Gain = gain;
    }

    /// <summary>
    /// <para>作用：ImpulseListener的Use 2D Distance参数设置</para>
    /// <para>use2dDistance：Use 2D Distance参数</para>
    /// </summary>
    public void ImpulseListener(bool use2dDistance)
    {
        InitComponents();
        cIL.m_Use2DDistance = use2dDistance;
    }

    /// <summary>
    /// <para>作用：设置CinemachineImpulseSource组件中的RawSignal</para>
    /// <para>gameObject：待设置的游戏对象（请提前确认该游戏对象是否有CinemachineImpulseSource组件）</para>
    /// <para>rawSignalOfPath：RawSignal中SignalSourceAsset文件的路径（根文件夹为Assets）</para>
    /// </summary>
    public void InitImpulseSource(GameObject gameObject, string rawSignalOfPath)
    {
        CinemachineImpulseSource cIS = gameObject.GetComponent<CinemachineImpulseSource>();
        NoiseSettings ns = AssetDatabase.LoadAssetAtPath<NoiseSettings>(rawSignalOfPath);
        if (ns != null && cIS != null)
        {
            CinemachineImpulseDefinition cID = cIS.m_ImpulseDefinition;
            cID.m_RawSignal = ns;
        }
        else
        {
            Debug.Log("HGH.CinemachineRenderer.InitImpulseSource:你的游戏对象不存在CinemachineImpulseSource组件或你的RawSignal中SignalSourceAsset文件的路径错误！");
        }
    }

    /// <summary>
    /// <para>作用：获取ImpulseSource的参数结构体</para>
    /// </summary>
    public ImpulseSourceAttribute GetImpulseSourceAttribute()
    {
        return new ImpulseSourceAttribute(true);
    }

    /// <summary>
    /// <para>作用：设置CinemachineImpulseSource组件中的RawSignal</para>
    /// <para>gameObject：待设置的游戏对象（请提前确认该游戏对象是否有CinemachineImpulseSource组件）</para>
    /// <para>rawSignalOfPath：RawSignal中SignalSourceAsset文件的路径（根文件夹为Assets）</para>
    /// </summary>
    public void InitImpulseSource(GameObject gameObject, ImpulseSourceAttribute sA)
    {
        CinemachineImpulseSource cIS = gameObject.GetComponent<CinemachineImpulseSource>();
        if (cIS != null)
        {
            CinemachineImpulseDefinition cID = cIS.m_ImpulseDefinition;
            cID.m_ImpulseChannel = getChannelMask(sA.impulseChannelName);
            cID.m_AmplitudeGain = sA.amplitudeGain.Value;
            cID.m_FrequencyGain = sA.frequencyGain.Value;
            cID.m_Randomize = sA.randomize;
            cID.m_ImpactRadius = sA.impactRadius;
            switch (sA.directionMode)
            {
                case DirectionMode.Fixed:
                    cID.m_DirectionMode = CinemachineImpulseManager.ImpulseEvent.DirectionMode.Fixed;
                    break;
                case DirectionMode.RotateTowardSource:
                    cID.m_DirectionMode = CinemachineImpulseManager.ImpulseEvent.DirectionMode.RotateTowardSource;
                    break;
                default:
                    break;
            }
            switch (sA.dissipationMode)
            {
                case DissipationMode.LinearDecay:
                    cID.m_DissipationMode = CinemachineImpulseManager.ImpulseEvent.DissipationMode.LinearDecay;
                    break;
                case DissipationMode.SoftDecay:
                    cID.m_DissipationMode = CinemachineImpulseManager.ImpulseEvent.DissipationMode.SoftDecay;
                    break;
                case DissipationMode.ExponentialDecay:
                    cID.m_DissipationMode = CinemachineImpulseManager.ImpulseEvent.DissipationMode.ExponentialDecay;
                    break;
                default:
                    break;
            }
            cID.m_DissipationDistance = sA.dissipationDistance;
            cID.m_PropagationSpeed = sA.propagationSpeed;
        }
        else
        {
            Debug.Log("HGH.CinemachineRenderer.InitImpulseSource:你的游戏对象不存在CinemachineImpulseSource组件！");
        }
    }

    /// <summary>
    /// <para>作用：添加CinemachineImpulseSource组件</para>
    /// <para>gameObject：待添加该组件的游戏对象</para>
    /// </summary>
    public void AddImpulseSource(GameObject gameObject)
    {
        gameObject.AddComponent<CinemachineImpulseSource>();
    }

    public void doImpulse(GameObject gameObject, Vector3 velocity)
    {
        CinemachineImpulseSource cIS = gameObject.GetComponent<CinemachineImpulseSource>();
        if (cIS != null)
        {
            cIS.GenerateImpulse(velocity);
        }
    }

    /// <summary>
    /// <para>说明:ImpulseSource的参数结构体</para>
    /// </summary>
    public struct ImpulseSourceAttribute
    {
        /// <summary>
        /// <para>ImpulseChannel的名称,默认为Nothing</para>
        /// </summary>
        public string impulseChannelName;
        public struct RangeValue
        {
            private float v;
            private float max;
            private float min;
            public float Value
            {
                get
                {
                    return v;
                }
                set
                {
                    if (value < min)
                    {
                        v = min;
                    }
                    else if (value > max)
                    {
                        v = max;
                    }
                    else v = value;
                }
            }
            public RangeValue(float def, float max, float min)
            {
                if (def >= min && def <= max)
                {
                    v = def;
                }
                else
                {
                    v = min;
                }
                this.max = max;
                this.min = min;
            }

            public RangeValue(float def)
            {
                min = 0;
                max = 1;
                if (def >= this.min && def <= this.max)
                {
                    v = def;
                }
                else
                {
                    v = this.min;
                }
            }
        }
        /// <summary>
        /// <para>控制抖动强度的参数,原始信号乘上该数值,范围(0-1),默认为1</para>
        /// </summary>
        public RangeValue amplitudeGain;
        /// <summary>
        /// <para>控制抖动速度的参数,原始信号乘上该数值,范围(0-1),默认为1</para>
        /// </summary>
        public RangeValue frequencyGain;
        /// <summary>
        /// <para>是否开启随机化原始信号开始时间的功能,默认开启</para>
        /// </summary>
        public bool randomize;
        /// <summary>
        /// <para>该参数为冲击半径,信号的总影响半径为冲击半径+耗散距离,默认为100</para>
        /// </summary>
        public float impactRadius;
        /// <summary>
        /// <para>定义当脉冲监听器离开脉冲源时，Cinemachine脉冲源组件应如何应用信号方向，默认为Fixed。</para>
        /// <para>使用说明：CinemachineRenderer.DirectionMode.xxx</para>
        /// <para>----Fixed：使用"固定"可使用恒定的信号方向。</para>
        /// <para>----RotateTowardSource：使用"向源旋转"沿脉冲源的方向旋转信号,提供有关源位置的细微视觉线索，向源方向旋转对径向对称信号没有影。</para>
        /// </summary>
        public DirectionMode directionMode;
        /// <summary>
        /// <para>定义当侦听器位于碰撞半径之外时，信号如何消散，默认为ExponentialDecay。</para>
        /// <para>使用说明：CinemachineRenderer.DissipationMode.xxx</para>
        /// <para>----LinearDecay：信号在耗散距离上均匀耗散。</para>
        /// <para>----SoftDecay：信号在耗散距离开始时缓慢耗散，在中间更快，到达终点时再次缓慢耗散。</para>
        /// <para>----ExponentialDecay：信号在耗散距离开始时耗散得非常快，然后在到达终点时耗散得越来越慢。</para>
        /// </summary>
        public DissipationMode dissipationMode;
        /// <summary>
        /// <para>设置碰撞半径以外的距离，在该距离内，信号从最大强度衰减为零，默认为1000。</para>
        /// </summary>
        public float dissipationDistance;
        /// <summary>
        /// <para>脉冲在空间中传播的速度（米/秒）。高速使听者能够瞬间做出反应，而低速使场景中的听者能够做出反应，就好像是对源中传播的波作出反应一样，默认为343。</para>
        /// </summary>
        public float propagationSpeed;
        public ImpulseSourceAttribute(bool isActive)
        {
            impulseChannelName = "Nothing";
            amplitudeGain = new RangeValue(1);
            frequencyGain = new RangeValue(1);
            randomize = true;
            impactRadius = 100;
            directionMode = DirectionMode.Fixed;
            dissipationMode = DissipationMode.ExponentialDecay;
            dissipationDistance = 1000;
            propagationSpeed = 343;
        }
    }


    public enum DirectionMode
    {
        Fixed = 0,
        RotateTowardSource = 1
    }

    public enum DissipationMode
    {
        LinearDecay = 0,
        SoftDecay = 1,
        ExponentialDecay = 2
    }
}
#endif