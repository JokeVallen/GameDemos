using UnityEngine;
using EasyGame;

public class MechanismTrapView : ViewController
{
    [Header("必要组件")]
    //cPoints数组用于设置可移动平台的两个顶点
    [Tooltip("设置可移动平台的两个顶点,第一个为上或左，第二个为下或右")]
    public Transform[] cPoints;
    //cRigid_body为该脚本挂载对象的Rigidbody 2D组件
    private Rigidbody2D cRigid_body;
    //触发器
    private ITrapTrigger cTrigger;

    [Header("平台属性设置")]
    //mSpeed表示平台移动的速度
    [Tooltip("物体移动的速度")]
    public float mSpeed;
    //mMoveDirections表示平台移动的方向(0表示左右,1表示上下)
    [Tooltip("物体运动的方向(0表示左右,1表示上下)")]
    public int mMoveDirections;
    //true表示左或上，false表示右或下
    private bool mBlock_direction = true;
    //判断Rigidbody2d组件是否获取成功
    private bool mGetcom_Rigidbody2d;
    //mTrigger_check用于检测主角是否进入机关陷阱触发区域
    private bool mTrigger_check;
    //mTrap_status用于表示当前陷阱的启用状态,默认为false即未启动
    private bool mTrap_status;

    private void Awake() {
        var tr=GetComponent<TrapTrigger>();
        if(tr != null)
        {
            cTrigger = tr as ITrapTrigger;
            cTrigger.cTriC=tr as ITrapTriggerComponents;
            cTrigger.cTriP=tr as ITrapTriggerParameters;
            cTrigger.cTriF=tr as ITrapTriggerFunc; 
        }
        //获取刚体组件
        mGetcom_Rigidbody2d = TryGetComponent<Rigidbody2D>(out cRigid_body);
    }

    void Update()
    {
        //陷阱未启动则始终保持检测主角是否进入触发区域的状态
        if(!mTrap_status)
        {
           mTrigger_check = cTrigger.cTriF.TriggerCheck();
        }
        //主角进入触发区域则启动陷阱并停止检测
        if(mTrigger_check)
        {
            BM_Movement();
            BM_ChangeDirection();
            mTrap_status = true;
        }
    }

    /// <summary>
    /// 作用：实现平台的移动
    /// </summary>
    void BM_Movement()
    {
        if(mGetcom_Rigidbody2d)
        {
            //左右移动
            if (mMoveDirections == 0)
            {
                if (mBlock_direction)
                    cRigid_body.velocity = new Vector2(-mSpeed, cRigid_body.velocity.y);
                else
                    cRigid_body.velocity = new Vector2(mSpeed, cRigid_body.velocity.y);
            }
            //上下移动
            if (mMoveDirections == 1)
            {
                if (mBlock_direction)
                    cRigid_body.velocity = new Vector2(cRigid_body.velocity.x, mSpeed);
                else
                    cRigid_body.velocity = new Vector2(cRigid_body.velocity.x, -mSpeed);
            }
        }
        
    }

    /// <summary>
    /// 作用：改变平台移动方向
    /// </summary>
    void BM_ChangeDirection()
    {
        if (mMoveDirections == 0)
        {
            if (transform.position.x <= cPoints[0].position.x)
            {
                //方向改为右
                mBlock_direction = false;
            }
            if(transform.position.x >= cPoints[1].position.x)
            {
                //方向改为左
                mBlock_direction = true;
            }
        }
        if (mMoveDirections == 1)
        {
            if (transform.position.y >= cPoints[0].position.y)
            {
                //方向改为下
                mBlock_direction = false;
            }
            if(transform.position.y <= cPoints[1].position.y)
            {
                //方向改为上
                mBlock_direction = true;
            }
        }
    }
}

