using UnityEngine;
using EasyGame;
using System.Collections.Generic;

public class FallTrapView : ViewController
{
    [Header("必要组件")]


    //cPoints数组用于设置可移动平台的两个顶点
    [Tooltip("设置可移动平台的两个顶点,第一个为上或左，第二个为下或右")]
    public Transform[] cPoints;
    [Tooltip("掉落陷阱的游戏对象的类型")]
    public GameObject cFallTrap;
    //记录第一个掉落陷阱的初始坐标
    private Vector3 cFallTrap_position;

    [Header("平台属性设置")]

    //mSpeed表示平台移动的速度
    [Tooltip("物体移动的速度")]
    public float mSpeed;
    //mMoveDirections表示平台移动的方向(0表示左右,1表示上下)
    [Tooltip("物体运动的方向(0表示左右,1表示上下)")]
    public int mMoveDirections;
    //mFallTrapCount表示单个掉落陷阱的陷阱数量
    [Tooltip("单个掉落陷阱的陷阱数量")]
    public int mFallTrapCount = 1;
    //mFallTrapDistance表示单个掉落陷阱的陷阱间距
    [Tooltip("单个掉落陷阱的陷阱间距")]
    public float mFallTrapDistance;
    //mFallTrapDelayTime用于表示掉落陷阱的掉落延迟时间
    [Tooltip("掉落陷阱的掉落延迟时间(float型,推荐数值0.5~1.0)")]
    public float mFallTrapDelayTime;
    //true表示左或上，false表示右或下
    private bool mBlock_direction = true;

    void Start()
    {
        //初始化cFallTrap_position组件
        cFallTrap_position = cFallTrap.transform.position;
        //克隆可掉落陷阱
        for (int i = 1; i <= mFallTrapCount; i++)
        {
            Instantiate(cFallTrap, new Vector3(cFallTrap_position.x + mFallTrapDistance * i, cFallTrap_position.y, cFallTrap_position.z), Quaternion.identity, transform);
        }
        //默认掉落方向为向下
        mBlock_direction = false;
    }

    void Update()
    {
        BM_Movement();
        BM_CheckTrapEnd();
    }

    /// <summary>
    /// 作用：实现平台的移动
    /// </summary>
    void BM_Movement()
    {
        //左右移动
        if (mMoveDirections == 0)
        {
            if (mBlock_direction)
                transform.Translate(-mSpeed * Time.fixedDeltaTime, 0, 0);
            else
                transform.Translate(mSpeed * Time.fixedDeltaTime, 0, 0);
        }
        //上下移动
        if (mMoveDirections == 1)
        {
            if (mBlock_direction)
                transform.Translate(0, mSpeed * Time.fixedDeltaTime, 0);
            else
                transform.Translate(0, -mSpeed * Time.fixedDeltaTime, 0);
        }

    }

    /// <summary>
    /// 作用：改变平台移动方向
    /// </summary>
    void BM_ChangeDirection()
    {
        if (mMoveDirections == 0)
        {
            if (transform.position.x <= cPoints[0].position.x)
            {
                //方向改为右
                mBlock_direction = false;
            }
            if (transform.position.x >= cPoints[1].position.x)
            {
                //方向改为左
                mBlock_direction = true;
            }
        }
        if (mMoveDirections == 1)
        {
            if (transform.position.y >= cPoints[0].position.y)
            {
                //方向改为下
                mBlock_direction = false;
            }
            if (transform.position.y <= cPoints[1].position.y)
            {
                //方向改为上
                mBlock_direction = true;
            }
        }
    }

    /// <summary>
    /// 作用：检测掉落陷阱是否下落至结束点
    /// </summary>
    void BM_CheckTrapEnd()
    {
        if (mMoveDirections == 1)
        {
            if (transform.position.y <= cPoints[1].position.y - cFallTrap_position.y)
            {
                Invoke("BM_ReturnStartingPoint", mFallTrapDelayTime);
            }
        }
    }

    /// <summary>
    /// 作用：将掉落陷阱的位置调整至初始的下落点
    /// </summary>
    void BM_ReturnStartingPoint()
    {
        transform.position = new Vector2(transform.position.x, cFallTrap_position.y);
    }
}

