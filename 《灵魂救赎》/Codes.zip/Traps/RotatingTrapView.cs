using UnityEngine;
using EasyGame;

public class RotatingTrapView : ViewController
{
    [Header("必要组件")]

    //cSwingTrap为旋转陷阱的组成对象之一
    [Tooltip("SwingTrap")]
    public GameObject cSwingTrap;
    //cRigid_body为SwingTrap的Rigidbody 2D组件,SwingTrap为该脚本挂载对象的子物体
    private Rigidbody2D cRigid_body;
    //触发器
    private ITrapTrigger cTrigger;

    //判断组件是否获取成功
    private bool mGet_com = false;
    //mTrigger_check用于检测主角是否进入机关陷阱触发区域
    private bool mTrigger_check;
    //mTrap_status用于表示当前陷阱的启用状态,默认为false即未启动
    private bool mTrap_status;

    void Start()
    {
        var tr=GetComponent<TrapTrigger>();
        if(tr != null)
        {
            cTrigger = tr as ITrapTrigger;
            cTrigger.cTriC=tr as ITrapTriggerComponents;
            cTrigger.cTriP=tr as ITrapTriggerParameters;
            cTrigger.cTriF=tr as ITrapTriggerFunc; 
        }
        //获取刚体组件
        mGet_com = cSwingTrap.transform.TryGetComponent<Rigidbody2D>(out cRigid_body);
    }

    void Update()
    {
        //陷阱未启动则始终保持检测主角是否进入触发区域
        if(!mTrap_status)
        {
            mTrigger_check = cTrigger.cTriF.TriggerCheck();
        }
        //主角进入触发区域则启动陷阱并停止检测
        if(mTrigger_check)
        {
            TrapOpen();
            mTrap_status = true;
        }
    }

    /// <summary>
    /// 作用:用于开启旋转陷阱
    /// </summary>
    void TrapOpen()
    {
        if(mGet_com)
        {
            cRigid_body.simulated = true;
        }
    }
}

