using UnityEngine;
using EasyGame;
using Cinemachine;

public class BoomTrapView : ViewController
{
    [Header("必要组件")]

    [Tooltip("虚拟相机对象")]
    public CinemachineVirtualCamera cVCmera;
    private Animator cAnimt;

    [Header("必要变量")]

    [Tooltip("屏幕抖动的三维向量值,调节该数值可以设置屏幕抖动程度,正负表示方向,数值大小表示程度")]
    public Vector3 mVco3;
    private bool mGet_Animator;
    [SerializeField] GameObject attackArea;

    private void Start()
    {
        mGet_Animator = TryGetComponent<Animator>(out cAnimt);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player" && mGet_Animator)
        {
            cAnimt.SetBool("Pre_boom", true);
        }
    }

    public void BoomStart()
    {
        GetComponent<CinemachineImpulseSource>().GenerateImpulse(mVco3);
        cAnimt.SetBool("Pre_boom", false);
        attackArea.SetActive(true);
        GetComponent<SpriteRenderer>().enabled = false;
        // Destroy(gameObject);
    }

    public void BoomOver()
    {
        attackArea.SetActive(false);
        Destroy(gameObject);
    }

}

