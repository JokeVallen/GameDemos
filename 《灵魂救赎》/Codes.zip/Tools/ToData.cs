using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToData
{
    public static ToData instance = new ToData();

    public float toFloat(double p_data)
    {
        return (float)p_data;
    }

    public List<float> toFloat(List<double> p_data)
    {
        List<float> list = new List<float>();
        foreach (var item in p_data)
        {
            list.Add(toFloat(item));
        }
        return list;
    }

    public double toDouble(float p_data)
    {
        return (double)p_data;
    }

    public List<double> toDouble(List<float> p_data)
    {
        List<double> list = new List<double>();
        foreach (var item in p_data)
        {
            list.Add(toDouble(item));
        }
        return list;
    }

    public string[] toString(List<string> p_data)
    {

        string[] str = new string[p_data.Count];
        for (int i = 0; i < p_data.Count; i++)
        {
            str[i] = (string)p_data[i];
        }
        return str;
    }

    public List<string> toList(string[] p_data)
    {
        List<string> list = new List<string>();
        list.Clear();
        foreach (var item in p_data)
        {
            list.Add(item);
        }
        return list;
    }
}
