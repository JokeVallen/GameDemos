using UnityEngine;
using EasyGame;
using UnityEngine.SceneManagement;

public class TeachToFirst : ViewController
{
    [Header("必要组件")]
    [Tooltip("提示标语")]
    [SerializeField] private GameObject cTip;
    private ITrapTrigger cTrigger;
    private bool isEnter;

    private void Awake()
    {
        var tr = GetComponent<TrapTrigger>();
        if (tr != null)
        {
            cTrigger = tr as ITrapTrigger;
            cTrigger.cTriC = tr as ITrapTriggerComponents;
            cTrigger.cTriP = tr as ITrapTriggerParameters;
            cTrigger.cTriF = tr as ITrapTriggerFunc;
        }
    }

    private void Update()
    {
        isEnter = cTrigger.cTriF.TriggerCheck();
        TipActive();
        if (isEnter && Input.GetKeyDown(KeyCode.T) && SceneManager.GetActiveScene().name.Equals("TeachLevel"))
        {
            SceneManager.LoadScene("DesperateForest");
        }
        else if (isEnter && Input.GetKeyDown(KeyCode.T) && SceneManager.GetActiveScene().name.Equals("DesperateForest"))
        {
            SceneManager.LoadScene("TeachLevel");
        }
    }

    private void TipActive()
    {
        if (isEnter)
        {
            cTip.SetActive(true);
        }
        else
        {
            cTip.SetActive(false);
        }
    }
}
