using System.Collections;
using UnityEngine;
using EasyGame;


/// <summary>
/// 作用：移动点光源实现局部打光的效果
/// </summary>
public class PointLightActiveView : ViewController
{
    [Header("必要组件")]
    [Tooltip("限定区域,通过调整BoxCollider2D来设置")]
    public BoxCollider2D cArea;
    [Header("必要属性")]
    [Tooltip("时间，单位为s")]
    public float mTime;
    [Tooltip("移动速度,float型")]
    [Range(1,2)]
    public float mSpeed;
    [Tooltip("PointLight与随机点之间的检测距离")]
    [Range((float)0.5,1)]
    public float mCheckDistance;
    //限定区域中心点
    private Vector2 mAreaPoint;
    //中心点
    private Vector2 mPoint;
    //随机点
    private Vector2 mRandomPoint;
    //最大宽度
    private float mWidth;
    //最大高度
    private float mHeight;
    //角度的tan值
    private float mAngle;
    //横向方向值
    private int mDirectionX = 1;
    //纵向方向值
    private int mDirectionY = 1;
    //是否到达了指定随机点,默认初始值为true
    private bool isAchieve = true;
    //倒计时是否结束
    private bool isDeadTime;

    void Start()
    {
        //获取限定区域中心点
        mAreaPoint = new Vector2(cArea.offset.x-cArea.bounds.center.x,cArea.offset.y-cArea.bounds.center.y);
        mWidth = cArea.size.x;
        mHeight = cArea.size.y;
        StartCoroutine(CountDown());
    }

    void FixedUpdate()
    {
        if(!isDeadTime)
        {
            if(isAchieve)
            {
                GetRandomPoint();
                GetAngle();
                GetDirection();
                isAchieve = false;
            }
            else
            {
                CheckAchieve();
                Movement();
            }
        }
    }

    //获取随机点
    private void GetRandomPoint()
    {
        do{
            var offsetX = Random.Range(mAreaPoint.x-mWidth/2,mAreaPoint.x+mWidth/2);
            var offsetY = Random.Range(mAreaPoint.y-mHeight/2,mAreaPoint.y+mHeight/2);
            mRandomPoint = new Vector2(offsetX,offsetY);
            mPoint = transform.localPosition;
        }while(Mathf.Abs(mPoint.x-mRandomPoint.x) < mWidth/4 && Mathf.Abs(mPoint.y-mRandomPoint.y) < mHeight/4);
    }

    private void GetAngle()
    {
        var sizeY = Mathf.Abs(mPoint.y-mRandomPoint.y);
        var sizeX = Mathf.Abs(mPoint.x-mRandomPoint.x);
        mAngle = sizeY/sizeX;
    }

    private void GetDirection()
    {
        if(mPoint.x > mRandomPoint.x)
            mDirectionX = -1;
        else
            mDirectionX = 1;
        if(mPoint.y > mRandomPoint.y)
            mDirectionY = -1;
        else
            mDirectionY = 1;
    }

    private void Movement()
    {
        if(!isAchieve)
            transform.Translate(mDirectionX*mSpeed*Time.fixedDeltaTime,mDirectionY*mAngle*mSpeed*Time.fixedDeltaTime,0);
    }

    private void CheckAchieve()
    {
        mPoint = transform.localPosition;
        var distance = Vector2.Distance(mPoint,mRandomPoint);
        if(distance < mCheckDistance)
            isAchieve = true;
    }

    IEnumerator CountDown()
    {
        while(mTime > 0)
        {
            yield return new WaitForSeconds(1);
            mTime--;
        }
        isDeadTime = true;
    }
}