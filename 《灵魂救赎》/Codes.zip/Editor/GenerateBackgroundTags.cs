using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEditor;

public class GenerateBackgroundTags : ScriptableObject
{
    [Header("背景精灵数据")]
    public List<mSprite> mSpiriteList = new List<mSprite>();
    [Header("标签数据")]
    public List<string> mTagList = new List<string>();
    private string mPath = Application.streamingAssetsPath + "/Data_HGH/BkTag.json";

    private void Awake()
    {
        readData();
    }

    /// <summary>
    /// <para>作用：刷新数据</para>
    /// </summary>
    public void customUpdate()
    {
        CheckValue();
    }

    private void updateData()
    {
        mData data = new mData(mSpiriteList, mTagList);
        if (File.Exists(mPath))
        {
            File.WriteAllText(mPath, toJsonStr(data));
        }
        else
        {
            Debug.Log("HGH:存储失败！！");
        }
    }

    /// <summary>
    /// <para>作用：读取数据</para>
    /// </summary>
    private void readData()
    {
        if (File.Exists(mPath))
        {
            string jsonStr = File.ReadAllText(mPath);
            if (jsonStr != "")
            {
                mData data = JsonUtility.FromJson<mData>(jsonStr);
                mSpiriteList = data.mSpiriteList;
                mTagList = data.mTagList;
            }
        }
        else
        {
            Debug.Log("HGH:读取失败！！");
        }
    }

    /// <summary>
    /// <para>作用：数据转换为Json字符串</para>
    /// </summary>
    private string toJsonStr(mData p_data)
    {
        return JsonUtility.ToJson(p_data);
    }

    /// <summary>
    /// <para>作用：更新标签</para>
    /// <para>p_tags：标签数据</para>
    /// </summary>
    public void update_mTagLists(string[] p_tags)
    {
        mTagList = ToData.instance.toList(p_tags);
        customUpdate();
    }

    /// <summary>
    /// <para>作用：获取标签</para>
    /// </summary>
    public string[] get_mTagLists()
    {
        customUpdate();
        return ToData.instance.toString(mTagList);
    }

    /// <summary>
    /// <para>作用：更新背景精灵数据</para>
    /// <para>p_key：背景精灵名称</para>
    /// <para>p_value：背景精灵数据</para>
    /// </summary>
    public void update_mSprite(string p_key, List<float> p_value)
    {
        mSpiriteList.Add(new mSprite(p_key, ToData.instance.toDouble(p_value)));
        mTagList.Add(p_key);
        customUpdate();
    }

    /// <summary>
    /// <para>作用：获取背景精灵数据</para>
    /// </summary>
    public List<float> get_mSprite(string p_key)
    {
        foreach (var item in mSpiriteList)
        {
            if (item.key == p_key)
            {
                return ToData.instance.toFloat(item.value);
            }
        }
        return null;
    }

    /// <summary>
    /// <para>作用：检查标签数据和背景精灵树</para>
    /// </summary>
    private void CheckValue()
    {
        //要删除的标签元素的索引列表
        List<int> removeIndex_tag = new List<int>();
        //要删除的精灵元素的索引列表
        List<int> removeIndex_sprite = new List<int>();
        for (int i = 0; i < mTagList.Count; i++)
        {
            bool isExist = false;
            //遍历查找标签列表是否存在相同元素
            for (int j = i + 1; j < mTagList.Count; j++)
            {
                if (mTagList[j].Equals(mTagList[i]))
                {
                    removeIndex_tag.Add(j);
                }
            }
            //遍历查找精灵列表是否存在相同元素、精灵列表是否包含当前所遍历标签对应的精灵信息
            for (int m = 0; m < mSpiriteList.Count; m++)
            {
                var item = mSpiriteList[m];
                for (int n = m + 1; n < mSpiriteList.Count; n++)
                {
                    var d_item = mSpiriteList[n];
                    if (item.key.Equals(d_item.key))
                    {
                        removeIndex_sprite.Add(n);
                    }
                }
                if (item.key.Equals(mTagList[i]))
                {
                    //当前所遍历标签对应的精灵信息中的值是否为空或者包括0
                    if (item.value == null || item.value.Contains(0))
                    {
                        isExist = false;
                    }
                    else
                    {
                        isExist = true;
                    }
                }
            }
            //当前所遍历标签对应的精灵信息不符合存储条件
            if (!isExist)
            {
                removeIndex_tag.Add(i);
            }
        }
        //根据两个元素删除索引列表进行删除
        foreach (var v_index in removeIndex_sprite)
        {
            if (v_index >= 0 && v_index < mSpiriteList.Count)
            {
                mSpiriteList.RemoveAt(v_index);
            }
        }
        foreach (var v_index in removeIndex_tag)
        {
            if (v_index >= 0 && v_index < mTagList.Count)
            {
                mTagList.RemoveAt(v_index);
            }
        }
        updateData();
    }
}

[System.Serializable]
public struct mSprite
{
    public string key;
    public List<double> value;
    public mSprite(string key, List<double> value)
    {
        this.key = key;
        this.value = value;
    }
}

[System.Serializable]
public struct mData
{
    public List<mSprite> mSpiriteList;
    public List<string> mTagList;

    public mData(List<mSprite> mSpiriteList, List<string> mTagList)
    {
        this.mSpiriteList = mSpiriteList;
        this.mTagList = mTagList;
    }
}