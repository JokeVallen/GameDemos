using System.Collections.Generic;
using UnityEngine;
using EasyGame.EditorTools;
using UnityEditor;

/// <summary>
/// <para>作用：生成背景</para>
/// <para>模式：手动生成模式、快速生成模式</para>
/// </summary>
public class GenerateBackground : CreateScriptWizard<GenerateBackground>
{
    //[Header("公共组件")]
    //Tag存储对象
    [SerializeField]
    private GenerateBackgroundTags cTagMemory;
    //背景游戏对象数组
    private GameObject[] cBgArray;
    //使用说明文件
    private TextAsset cHelpTips;

    [Header("公共属性")]
    [Tooltip("生成方向")]
    public mTypes mDirectionType = mTypes.left;
    [Tooltip("生成个数")]
    public int mCount;
    [Tooltip("背景对象已存在个数")]
    public int existCount;
    //内部类ManualMode对象
    private ManualMode mManualMode;
    //内部类QuickMode对象
    private QuickMode mQuickMode;
    //滚动视图坐标
    private Vector2 mScrollPos = new Vector2(0, 0);
    //资源路径
    private const string mAssetPath = "Assets_HGH/BackgroundTag";
    //文本资源路径
    private const string mTextAssetPath = "Assets_HGH/ReadMe_GenerateBK";
    //模式选项数组
    private static string[] mTagModes;
    //文本内容
    private string[] mTextContext;
    //水平方向的值，向左值为1，向右值为-1
    private int mDirectionX;
    //垂直方向的值，向上值为1，向下值为-1
    private int mDirectionY;
    //被选中Tag的索引
    private int mIndex;
    //模式索引
    private int mModeIndex = 0;
    //方向值，左右值为true，上下值为false
    private bool mDirection;
    //外部类变量
    private static GenerateBackground mGB;
    //枚举
    public enum mTypes
    {
        left, right, up, down
    };

    [SerializeReference]
    mDisplay display;

    [MenuItem("EasyGame/创建背景", false, 51)]
    static void CreateWizard()
    {
        InitWizard("创建背景", "创建", 300, 400);
        mTagModes = new string[2] { "手动生成模式", "快速生成模式" };
    }

    //点击按钮执行的方法
    private void OnWizardCreate()
    {
        if (mModeIndex == 0)
        {
            mManualMode.CopyBK_ManualMode();
        }
        else
        {
            mQuickMode.CopyBK_QuickMode();
        }
        this.Close();
    }

    private void Awake()
    {
        mGB = this;
        mManualMode = new ManualMode();
        mQuickMode = new QuickMode();
        cTagMemory = Resources.Load<GenerateBackgroundTags>(mAssetPath);
        cHelpTips = Resources.Load<TextAsset>(mTextAssetPath);
        DealTextAsset();
    }

    private void Init()
    {
        cBgArray = new GameObject[mCount];
    }

    [System.Serializable]
    private class mDisplay { }
    [System.Serializable]
    private class ManualMode : mDisplay
    {
        [Header("必要组件")]
        [Tooltip("背景游戏对象")]
        public GameObject cBackground;
        [Tooltip("背景精灵")]
        public Sprite cBgSprite;

        [Header("必要属性")]
        //背景对象缩放比例
        private Vector2 mScale;
        //背景对象的坐标
        private Vector3 mPosition;
        //处理后的背景精灵的宽
        public float mWidth { get; private set; }
        //处理后的背景精灵的高
        public float mHeight { get; private set; }
        //背景对象数据：记录背景精灵的宽和高
        private List<float> mList = new List<float>();

        //手动生成背景模式的初始化方法
        public void ManualModeInit()
        {
            if (cBackground && cBgSprite)
            {
                mScale = cBackground.transform.localScale;
                mPosition = cBackground.transform.position;
                mWidth = cBgSprite.bounds.size.x;
                mHeight = cBgSprite.bounds.size.y;
            }
        }

        public void CopyBK_ManualMode()
        {
            if (cBackground && cBgSprite)
            {
                mGB.CopyBK(cBackground, mPosition, mWidth, mHeight);
                mList.Add(mWidth);
                mList.Add(mHeight);
                mGB.cTagMemory.update_mSprite(cBackground.tag, mList);
            }
        }
    }

    //快速生成
    [System.Serializable]
    private class QuickMode : mDisplay
    {
        //[Header("必要组件")]
        //背景游戏对象
        private GameObject cBackground;
        [Header("必要属性")]
        [Tooltip("快速生成背景对象的Tag(可以添加、删除、修改Tag)")]
        //Tag数组
        public string[] mTagArray;
        [Tooltip("标签可编辑模式")]
        //是否进入标签可编辑模式
        public bool isEditMode;
        //Tag选项数组
        public string[] mTagOptions { get; private set; }


        //快速生成背景模式的初始化方法
        public void QuickModeInit()
        {
            var sourceTags = mGB.cTagMemory.get_mTagLists();
            if (!isEditMode)
            {
                if (sourceTags?.Length != 0)
                {
                    Debug.Log("sourceTags不为空！！");
                    mTagArray = new string[sourceTags.Length];
                    mGB.cTagMemory.get_mTagLists().CopyTo(mTagArray, 0);
                    mTagOptions = mTagArray;
                }
                else
                {
                    Debug.Log("sourceTags为空！！");
                    mTagArray = null;
                }
            }

        }

        public void CopyBK_QuickMode()
        {
            if (mTagOptions?.Length != 0 && mTagOptions != null && !isEditMode)
            {
                cBackground = GameObject.FindGameObjectWithTag(mTagOptions[mGB.mIndex]);
            }
            if (cBackground)
            {
                var varList = mGB.cTagMemory.get_mSprite(cBackground.tag);
                if (varList != null)
                {
                    mGB.CopyBK(cBackground, cBackground.transform.position, varList[0], varList[1]);
                }
                else
                {
                    Debug.Log("HGH:生成失败,你要快速生成的背景未手动生成过！");
                }
            }
        }

        //快速生成模式刷新标签
        public void CheckData()
        {
            if (mGB.cTagMemory != null && mTagArray?.Length != 0 && isEditMode)
            {
                Debug.Log("CheckData!!!");
                mGB.cTagMemory.update_mTagLists(mTagArray);
            }
        }
    }

    /// <summary>
    /// <para>作用：方向选择</para>
    /// </summary>
    private void GenerateBK()
    {
        Debug.Log("GenerateBK");
        switch (mDirectionType)
        {
            case mTypes.left:
                mDirectionX = 1;
                mDirection = true;
                break;
            case mTypes.right:
                mDirectionX = -1;
                mDirection = true;
                break;
            case mTypes.up:
                mDirectionY = 1;
                mDirection = false;
                break;
            case mTypes.down:
                mDirectionY = -1;
                mDirection = false;
                break;
            default:
                break;
        }
    }

    private void InitBk(GameObject gameObject, Vector3 vec, Transform transform, SpriteRenderer spriteRenderer, int index)
    {
        gameObject.transform.name = transform.name + index.ToString();
        gameObject.transform.position = vec;
        gameObject.transform.localScale = transform.localScale;
        gameObject.transform.parent = transform.parent;
        gameObject.tag = transform.tag;
        gameObject.layer = transform.gameObject.layer;
        gameObject.AddComponent<SpriteRenderer>();
        SpriteRenderer sr = gameObject.GetComponent<SpriteRenderer>();
        sr.sprite = spriteRenderer.sprite;
        sr.material = spriteRenderer.sharedMaterial;
        sr.sortingLayerID = spriteRenderer.sortingLayerID;
        sr.sortingOrder = spriteRenderer.sortingOrder;
        sr.renderingLayerMask = spriteRenderer.renderingLayerMask;
    }

    /// <summary>
    /// <para>作用：克隆背景</para>
    /// <para>cBackground：克隆源游戏对象</para>
    /// <para>mPosition：起始坐标</para>
    /// <para>mWidth：精灵宽度</para>
    /// <para>mHeight：精灵高度</para>
    /// </summary>
    private void CopyBK(GameObject cBackground, Vector3 mPosition, float mWidth, float mHeight)
    {
        if (mDirection)
        {
            for (int i = 0; i < mCount; i++)
            {
                Vector3 vec = new Vector3(mDirectionX * mPosition.x + (i + existCount) * mWidth * 2, mPosition.y, mPosition.z);
                EditorApplication.ExecuteMenuItem("GameObject/Create Empty");
                SpriteRenderer spriteRenderer = cBackground.GetComponent<SpriteRenderer>();
                InitBk(GameObject.Find("GameObject"), vec, cBackground.transform, spriteRenderer, i);
            }
        }
        else
        {
            for (int i = 0; i < mCount; i++)
            {
                Vector3 vec = new Vector3(mPosition.x, mDirectionY * mPosition.y + (i + existCount) * mHeight * 2, mPosition.z);
                EditorApplication.ExecuteMenuItem("GameObject/Create Empty");
                SpriteRenderer spriteRenderer = cBackground.GetComponent<SpriteRenderer>();
                InitBk(GameObject.Find("GameObject"), vec, cBackground.transform, spriteRenderer, i);
            }
        }
    }

    /// <summary>
    /// <para>作用：UI面板布局</para>
    /// </summary>
    private void OnGUI()
    {
        //更新面板数据
        mGB.cTagMemory.customUpdate();
        //UI控件滑动条区域开始位置
        mScrollPos = GUILayout.BeginScrollView(mScrollPos, false, true);
        //UI控件下拉选择框
        mModeIndex = EditorGUILayout.Popup("模式选择", mModeIndex, mTagModes, GUILayout.ExpandWidth(true));
        //手动生成模式
        if (mModeIndex == 0)
        {
            base.DrawWizardGUI();
            if (GUILayout.Button("创建背景", GUILayout.ExpandWidth(true)))
            {
                mManualMode.ManualModeInit();
                Init();
                GenerateBK();
                OnWizardCreate();
            }
            display = mManualMode;
            //UI控件提示信息
            EditorGUILayout.HelpBox(mTextContext[0], MessageType.Info, true);
        }
        //快速生成模式
        else
        {
            base.DrawWizardGUI();
            if (mQuickMode.mTagOptions != null && mQuickMode.mTagOptions?.Length != 0)
            {
                mIndex = EditorGUILayout.Popup("Tag数组", mIndex, mQuickMode.mTagOptions, GUILayout.ExpandWidth(true));
            }
            if (GUILayout.Button("刷新标签", GUILayout.ExpandWidth(true)))
            {
                mQuickMode.QuickModeInit();
                GenerateBK();
                mQuickMode.CheckData();
            }
            if (GUILayout.Button("快速生成", GUILayout.ExpandWidth(true)))
            {
                mQuickMode.QuickModeInit();
                Init();
                GenerateBK();
                OnWizardCreate();
            }
            display = mQuickMode;
            //UI控件提示信息
            EditorGUILayout.HelpBox(mTextContext[1], MessageType.Info, true);
        }
        //UI控件滑动条区域结束位置
        GUILayout.EndScrollView();
    }

    /// <summary>
    /// <para>作用：处理提示信息文本</para>
    /// </summary>
    private void DealTextAsset()
    {
        if (cHelpTips != null)
        {
            mTextContext = cHelpTips.text.Split(new string[] { "\r\n" }, System.StringSplitOptions.RemoveEmptyEntries);
        }
    }
}