using UnityEngine;

public class PlayerFollowPlatform : MonoBehaviour
{
    Rigidbody2D rigidbody2 => GetComponent<Rigidbody2D>();
    public Bounds bounds;
    public LayerMask layerMask;

    void Update()
    {
        PlayerChecker();
    }

    bool onArea;
    Collider2D player;
    BoxCollider2D boxCollider2 => GetComponent<BoxCollider2D>();
    void PlayerChecker()
    {
        Collider2D cur = Physics2D.OverlapBox(transform.position + bounds.center, bounds.size, 0, layerMask);

        if (cur && !onArea)//第一次进入
        {
            if (cur.gameObject.tag == "Player")
            {
                onArea = true;
                player = cur;
            }
        }
        else if (!cur && onArea)//离开
        {
            player.SendMessage("FallowThePlatform", Vector2.zero);
            onArea = false;
            player = null;
        }

        if (cur && cur.gameObject.tag == "Player")
        {
            if (cur.bounds.min.y < boxCollider2.bounds.max.y) return;

            player.SendMessage("FallowThePlatform", rigidbody2.velocity);
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireCube(transform.position + bounds.center, bounds.size);
    }
}

