using UnityEngine;
using EasyGame;

public class DeadLine : ViewController
{
    public GameObject cPlayer;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player" && cPlayer != null)
        {
            cPlayer.transform.localPosition = new Vector3(-0.45f, -2.63f, 0);
        }
    }
}

