using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine;
using EasyGame;

public class toNextScene : ViewController
{
    private void Start()
    {
        StartCoroutine(Timer(4));
    }

    IEnumerator Timer(float TimeCount)
    {
        while (TimeCount > 0)
        {
            yield return new WaitForSeconds(1.0f);
            TimeCount -= 1;
        }
        var currentIndex = SceneManager.GetActiveScene().buildIndex;
        if (currentIndex + 1 <= SceneManager.sceneCountInBuildSettings - 1)
        {
            SceneManager.LoadScene(currentIndex + 1);
        }
    }
}

