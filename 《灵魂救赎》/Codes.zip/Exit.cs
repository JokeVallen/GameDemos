using UnityEngine;
using EasyGame;

public class Exit : MonoBehaviour
{
    public void ExitGame()
    {
        Application.Quit();
    }
}

