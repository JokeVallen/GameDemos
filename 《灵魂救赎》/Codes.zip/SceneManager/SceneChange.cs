using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneChange
{
    private GameObject gameObject;
    private SceneReservation sr;

    private void Init()
    {
        if (gameObject == null)
        {
            gameObject = GameObject.Find("SceneReservation");
            sr = gameObject.GetComponent<SceneReservation>();
        }
    }

    public void ChangeScene(string sceneName)
    {
        Init();
        Scene scene = SceneManager.GetSceneByName(sceneName);
        if (scene != null && sr != null)
        {
            sr.StartChangeScene(scene);
        }
    }

    public void ChangeScene(int sceneIndex)
    {
        Init();
        Scene scene = SceneManager.GetSceneByBuildIndex(sceneIndex);
        if (scene != null && sr != null)
        {
            sr.StartChangeScene(scene);
        }
    }

    public void GameObjectReservation(GameObject[] gameObjects)
    {
        if (sr != null)
        {
            sr.gameObjects = gameObjects;
            sr.DontDestroyObjects();
        }
    }
}
