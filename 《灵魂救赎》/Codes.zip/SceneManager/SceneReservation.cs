using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine;

public class SceneReservation : MonoBehaviour
{
    [Header("保存游戏对象")]
    [Tooltip("请将要保存的游戏对象拖入此处")]
    public GameObject[] gameObjects;

    public void SetGameObjects(GameObject[] gameObjects)
    {
        this.gameObjects = gameObjects;
    }

    public void DontDestroyObjects()
    {
        foreach (var item in gameObjects)
        {
            DontDestroyOnLoad(item);
        }
        DontDestroyOnLoad(this);
    }

    public void StartChangeScene(Scene scene)
    {
        StartCoroutine(doChangeScene(scene));
    }

    IEnumerator doChangeScene(Scene scene)
    {
        Scene currentScene = SceneManager.GetActiveScene();
        yield return null;
    }
}
