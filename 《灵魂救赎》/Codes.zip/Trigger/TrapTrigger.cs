using UnityEngine;

public class TrapTrigger : MonoBehaviour, ITrapTriggerComponents, ITrapTriggerParameters, ITrapTriggerFunc, ITrapTrigger
{
    [Header("必要组件")]
    [Tooltip("触发器检测层")]
    [SerializeField] private LayerMask cTriggerLayer;
    public LayerMask TriggerLayer { get => cTriggerLayer; set => cTriggerLayer = value; }
    [Tooltip("触发器检测区域的坐标组件，也就是以这个坐标为检测区域的坐标")]
    [SerializeField] private Transform cTriggerArea;
    public Transform TriggerArea { get => cTriggerArea; set => cTriggerArea = value; }
    [Header("必要属性")]
    [Tooltip("触发器检测区域的半径（触发器是圆）")]
    [SerializeField] private float mTrapTriggerRadius;
    public float TrapTriggerRadius { get => mTrapTriggerRadius; set => mTrapTriggerRadius = value; }
    //Trigger_check用于检测主角是否进入触发区域
    public bool Trigger_check { get; set; }
    public ITrapTriggerComponents cTriC { get; set; }
    public ITrapTriggerParameters cTriP { get; set; }
    public ITrapTriggerFunc cTriF { get; set; }

    /// <summary>
    /// 作用：用于检测主角是否进入触发区域
    /// </summary>
    public bool TriggerCheck()
    {
        //如果检测区域组件为空
        if (!cTriggerArea)
        {
            Debug.Log("你的cTriggerArea为空，请挂载！");
        }
        else
        {
            //检测是否进入了触发区域
            if (!Physics2D.OverlapCircle(TriggerArea.position, TrapTriggerRadius, cTriggerLayer))
            {
                Trigger_check = false;
            }
            else
            {
                Trigger_check = true;
            }
        }
        return Trigger_check;
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(TriggerArea.position, TrapTriggerRadius);
    }
}

public interface ITrapTriggerComponents
{
    //区域检测层
    public LayerMask TriggerLayer { get; set; }
    //检测区域组件
    public Transform TriggerArea { get; set; }

}
public interface ITrapTriggerParameters
{
    //检测区域的半径
    public float TrapTriggerRadius { get; set; }
    //mTrigger_check用于检测主角是否进入机关陷阱触发区域
    public bool Trigger_check { get; set; }
}

public interface ITrapTriggerFunc
{
    bool TriggerCheck();
}


public interface ITrapTrigger
{
    //触发器的组件
    public ITrapTriggerComponents cTriC { get; set; }
    //触发器的参数
    public ITrapTriggerParameters cTriP { get; set; }
    //触发器方法
    public ITrapTriggerFunc cTriF { get; set; }
}
