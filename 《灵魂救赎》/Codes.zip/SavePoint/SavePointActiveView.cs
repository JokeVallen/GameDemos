using UnityEngine;
using EasyGame;

public class SavePointActiveView : ViewController
{
    [Header("必要属性")]
    [Tooltip("存档点可使用区域为BOX盒型区域,此变量为盒型区域的宽X与高Y")]
    public Vector2 mSize;
    [Tooltip("存档点可使用区域为BOX盒型区域,此变量为盒型区域的角度,默认为不旋转则为0")]
    public float mAngle;
    [Tooltip("存档点可使用区域为BOX盒型区域,此变量为检测区域针对的对象层")]
    public LayerMask mLayermask;
    [Tooltip("存档点索引号,第一个索引号为0")]
    public int mIndex;
    //待检测对象是否进入检测区域的状态值,进入则为true,未进入则为false
    private bool mIsEnter;
    //存档点功能可使用状态值,可使用则为true,不可使用则为false
    private bool mIsActive;
    //检测区域中心点变量
    private Vector2 mPoint;

    private void Start() 
    {
        mPoint = transform.position;
    }

    private void Update() 
    {
        Check_Enter();
        Set_SavePointStatus();
    }

    private void Set_SavePointStatus()
    {
        if(mIsEnter && !mIsActive)
        {
            mIsActive = true;
        }
    }

    private void Check_Enter()
    {
        //未进入检测区域
        if(!Physics2D.OverlapBox(mPoint,mSize,mAngle,mLayermask))
        {
            mIsEnter = false;
        }
        //进入检测区域
        else
        {
            mIsEnter = true;
        }
    }
}

