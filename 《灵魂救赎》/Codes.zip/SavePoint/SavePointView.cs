using UnityEngine;
using EasyGame;

public class SavePointView : ViewController
{
    [Header("必要组件")]
    
    [Tooltip("存档点游戏对象数组")]
    public GameObject[] cSavePoints;
    private Vector2[] cSavePointPositions;

    [Header("必要属性")]
    private int mIndex;
    //待检测对象是否进入检测区域的状态值,进入则为true,未进入则为false
    private bool mIsEnter;
    //存档点功能可使用状态值,可使用则为true,不可使用则为false
    private bool mIsActive;

    private void Start()
    {
        for(int i = 0;i < cSavePoints.Length;i++)
        {
            cSavePointPositions[i] = cSavePoints[i].transform.position;
        }
    }

    // private void Func_Save()
    // {
        
    // }

    private void Func_Delivery()
    {
        if(mIsActive && mIsEnter)
        {
            if(Input.GetKeyDown(KeyCode.E))
            {
                
            }
        }
    }
    
}

