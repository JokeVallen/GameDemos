using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EasyGame;

public class ExcDressUp : Excutor
{
    protected override void Init()
    {

    }

    protected override void Excute()
    {

    }
}
