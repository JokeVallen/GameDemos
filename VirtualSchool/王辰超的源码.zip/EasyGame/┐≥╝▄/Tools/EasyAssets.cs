using UnityEngine;

namespace EasyGame
{
    /// <summary>
    /// 游戏物体基类
    /// </summary>
    public class EasyAssets : ScriptableObject
    {

    }
}