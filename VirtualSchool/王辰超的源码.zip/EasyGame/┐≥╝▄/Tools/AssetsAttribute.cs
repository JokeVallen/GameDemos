using System;

/// <summary>
/// 游戏物体特性
/// </summary>
[AttributeUsage(AttributeTargets.Class, Inherited = false)]
public class AssetsAttribute : Attribute
{

}

